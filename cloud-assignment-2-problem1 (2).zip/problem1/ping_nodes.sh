#!/bin/bash
SRC=$1
DST=$2
ip netns exec $SRC ping -c 4 $(ip netns exec $DST ip -4 addr show | grep -oP '(?<=inet\s)\d+(\.\d+){3}')
