#!/bin/bash
set -e
ip link add name br1 type bridge
ip link set br1 up
ip link add name br2 type bridge
ip link set br2 up
create_node() {
  NODE=$1
  VETH_HOST=$2
  VETH_NS=$3
  IP=$4
  BRIDGE=$5
  ip netns add $NODE
  ip link add $VETH_HOST type veth peer name $VETH_NS
  ip link set $VETH_NS netns $NODE
  ip link set $VETH_HOST up
  ip link set $VETH_HOST master $BRIDGE
  ip netns exec $NODE ip link set lo up
  ip netns exec $NODE ip link set $VETH_NS up
  ip netns exec $NODE ip addr add $IP dev $VETH_NS
}
create_node node1 veth1 veth1-ns 172.0.0.2/24 br1
create_node node2 veth2 veth2-ns 172.0.0.3/24 br1
create_node node3 veth3 veth3-ns 10.10.1.2/24 br2
create_node node4 veth4 veth4-ns 10.10.1.3/24 br2
ip netns add router
ip link add veth-r1 type veth peer name veth-r1-ns
ip link set veth-r1 master br1
ip link set veth-r1 up
ip link set veth-r1-ns netns router
ip link add veth-r2 type veth peer name veth-r2-ns
ip link set veth-r2 master br2
ip link set veth-r2 up
ip link set veth-r2-ns netns router
ip netns exec router ip link set lo up
ip netns exec router ip link set veth-r1-ns up
ip netns exec router ip addr add 172.0.0.1/24 dev veth-r1-ns
ip netns exec router ip link set veth-r2-ns up
ip netns exec router ip addr add 10.10.1.1/24 dev veth-r2-ns
for NODE in node1 node2; do
  ip netns exec $NODE ip route add default via 172.0.0.1
done
for NODE in node3 node4; do
  ip netns exec $NODE ip route add default via 10.10.1.1
done
ip netns exec router sysctl -w net.ipv4.ip_forward=1
