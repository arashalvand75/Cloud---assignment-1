from flask import Flask, request, jsonify

app = Flask(__name__)
status_state = {"status": "OK"}

@app.route("/api/v1/status", methods=["GET", "POST"])
def status():
    global status_state
    if request.method == "GET":
        return jsonify(status_state), 200
    elif request.method == "POST":
        status_state = request.get_json()
        return jsonify(status_state), 201

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
