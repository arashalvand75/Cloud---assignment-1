# Problem 2 - Simple Container Runtime

## Description

This is a simple container runtime written in Python. It creates a container using Linux namespaces and chroot, and sets a custom hostname.

## Requirements

- Python 3
- sudo privileges
- `debootstrap` installed for creating Ubuntu rootfs
- Linux system with support for unshare and chroot

## Usage

```bash
sudo ./simple_container.py mycontainer
```

Optional memory limit (not implemented in this version):

```bash
sudo ./simple_container.py mycontainer 100
```

## Notes

- This container uses Ubuntu 20.04 minimal rootfs (installed via `debootstrap`)
- Bash inside container runs as PID 1
- The root filesystem is isolated under `/tmp/<hostname>_container`
