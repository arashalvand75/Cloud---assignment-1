#!/usr/bin/env python3
import os
import sys
import subprocess

if len(sys.argv) < 2:
    print("Usage: ./simple_container.py <hostname> [memory_limit_MB]")
    sys.exit(1)

hostname = sys.argv[1]
mem_limit = sys.argv[2] if len(sys.argv) > 2 else None
container_root = f"/tmp/{hostname}_container"

# Prepare container filesystem (assumes downloaded ubuntu rootfs)
if not os.path.exists(container_root):
    print(f"Creating container root filesystem at {container_root}")
    subprocess.run(["mkdir", "-p", container_root])
    subprocess.run(["debootstrap", "--variant=minbase", "focal", container_root, "http://archive.ubuntu.com/ubuntu/"])

# Prepare command
command = [
    "unshare",
    "--mount",
    "--uts",
    "--ipc",
    "--net",
    "--pid",
    "--fork",
    "--mount-proc",
    "chroot", container_root,
    "/bin/bash", "-c",
    f"hostname {hostname} && exec /bin/bash"
]

# If memory limit is provided (bonus)
if mem_limit:
    print("⚠️ Memory limitation not implemented in this version (requires cgroups v2).")

# Run the container
os.execvp(command[0], command)
